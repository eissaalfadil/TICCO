from ticco import AnalysisRegions, Image, Controller
import pytest
import numpy as np
import pandas as pd

def test_controller_corr_tile(path_mask_1, path_img_1):
    regions = AnalysisRegions(path_mask_1)
    img = Image(path_img_1)

    c = Controller(img, regions, dyx=4, dt=3)

    t = 5
    y = 20
    x = 30
    res = c.corr_tile(t, y, x)
    assert -1 <= res <= 1

    t = 1
    y = 20
    x = 30
    res = c.corr_tile(t, y, x)


def test_controller_corr_region(path_mask_1, path_img_1, tmp_path):

    regions = AnalysisRegions(path_mask_1)
    img = Image(path_img_1)
    c = Controller(img, regions, dyx=4, dt=3)

    assert (c.result_img[:] == 0).all()
    c.corr_region(0)
    assert (c.result_img[:] != 0).any()
    assert (c.result_img[:] <= 1).all()
    assert (c.result_img[:] >= -1).all()

    df = c.corr_region(1)

    c.to_ome_tif(tmp_path / "test.ome.tif")
    c.export_data(tmp_path)
    assert (tmp_path / "img_1_result_region_0.csv").exists()
    assert (tmp_path / "img_1_result_region_1.csv").exists()
    assert (tmp_path / "img_1_result_aggregated.csv").exists()

    agg = pd.read_csv(tmp_path / "img_1_result_aggregated.csv")
    assert "y" in agg.columns
    assert "x" in agg.columns

    with pytest.raises(AssertionError): # we only have region 0 and region 1
        c.corr_region(2)


def test_controller_corr_region_smoothed(path_mask_1, path_img_1):
    regions = AnalysisRegions(path_mask_1)
    img = Image(path_img_1)
    c = Controller(img, regions, dyx=3, dt=3, sigma_yx=1.3, sigma_z=1)

    assert (c.result_img[:] == 0).all()
    c.corr_region(0)
    assert (c.result_img[:] != 0).any()
    assert (c.result_img[:] <= 1).all()
    assert (c.result_img[:] >= -1).all()


def test_controller_corr_region_smoothed_edge(path_mask_1, path_img_1):
    regions = AnalysisRegions(path_mask_1)
    img = Image(path_img_1)
    c = Controller(img, regions, dyx=5, dt=3, sigma_yx=1.3, sigma_z=1)

    assert (c.result_img[:] == 0).all()
    c.corr_region(0)

    res = c.result_img[:]
    res = res[~np.isnan(res)]
    assert (res != 0).any()
    assert (res <= 1).all()
    assert (res >= -1).all()


def test_controller_parameters(path_mask_1, path_img_1):

    regions = AnalysisRegions(path_mask_1)
    img = Image(path_img_1)
    c = Controller(img, regions, dyx=5, dt=3, sigma_yx=1.3, sigma_z=1)

    p = c.parameters()
    assert p["window_size_yx"] == 11
    assert p["window_size_z"] == 5 # all z slices
    assert p["window_size_t"] == 7 # all z slices
