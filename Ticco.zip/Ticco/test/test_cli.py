import subprocess
from pathlib import Path

def test_end2end(tmp_path, path_img_1, path_mask_1):

    res = subprocess.run(["ticco",
                          str(path_img_1),
                          str(tmp_path),
                          "--mask", str(path_mask_1),
                          "--no-multiprocessing"])

    assert (tmp_path / "img_1_corr_parameters.csv").exists()
    assert (tmp_path / "img_1_result_aggregated.csv").exists()
    assert (tmp_path / "img_1_corr.ome.tif").exists()

    print(path_img_1)


def test_end2end_custom_params(tmp_path, path_img_1, path_mask_1):

    cmd = ["ticco",
           str(path_img_1),
           str(tmp_path),
           "--mask", str(path_mask_1),
           "--dyx", "4",
           "--dt", "2",
           "--sigma_yx", "1.5",
           "--sigma_z" , "0",
           "--no-multiprocessing"]

    res = subprocess.run(cmd)

    assert (tmp_path / "img_1_corr_parameters.csv").exists()
    assert (tmp_path / "img_1_result_aggregated.csv").exists()
    assert (tmp_path / "img_1_corr.ome.tif").exists()

    print(path_img_1)

def test_end2end_default_mask_fname(tmp_path, path_img_1):


    cmd = ["ticco",
           str(path_img_1),
           str(tmp_path),
           "--dyx", "4",
           "--dt", "2",
           "--sigma_yx", "1.5",
           "--sigma_z" , "0",
           "--no-multiprocessing"]

    res = subprocess.run(cmd)

    assert (tmp_path / "img_1_corr_parameters.csv").exists()
    assert (tmp_path / "img_1_result_aggregated.csv").exists()
    assert (tmp_path / "img_1_corr.ome.tif").exists()

    print(path_img_1)


def test_end2end_batch(tmp_path, path_test_data):


    filename_pattern = path_test_data / "*.ome.tif"

    cmd = ["ticco",
           str(path_test_data),
           str(tmp_path),
           "--filename-wildcard", "*.ome.tif",
           "--dyx", "4",
           "--dt", "2",
           "--sigma_yx", "1.5",
           "--sigma_z" , "0",]


    res = subprocess.run(cmd)

    assert (tmp_path / "img_1_corr_parameters.csv").exists()
    assert (tmp_path / "img_1_result_aggregated.csv").exists()
    assert (tmp_path / "img_1_corr.ome.tif").exists()

    assert (tmp_path / "img_2_corr_parameters.csv").exists()
    assert (tmp_path / "img_2_result_aggregated.csv").exists()
    assert (tmp_path / "img_2_corr.ome.tif").exists()
