from ticco import Image
import pytest


def test_image_shape(path_img_1):
    img = Image(path_img_1)

    assert img.nframes == 10
    assert img.nchannels == 2
    assert img.shape_zyx == (5, 100, 200)


def test_image_tile(path_img_1):
    img = Image(path_img_1)

    pixels = img.tile(t=4, y=20, x=30, dt=1, dy=5, dx=3)

    assert pixels.shape == (2, 3, 5, 11, 7)  # CTZYX

    pixels = img.tile(t=4, y=98, x=30, dt=1, dy=1, dx=3)
    assert pixels.shape == (2, 3, 5, 3, 7)  # CTZYX

    with pytest.raises(IndexError):
        pixels = img.tile(y=98, x=30, t=4, dy=2, dx=3, dt=1)

    with pytest.raises(AssertionError):
        pixels = img.tile(y=20, x=30, t=1, dy=2, dx=3, dt=3)


def test_image_tile(path_img_1):
    img = Image(path_img_1)

    pixels = img.tile(t=4, y=20, x=30, dt=1, dy=5, dx=3)


def test_image_smoothed_tile(path_img_1):
    img = Image(path_img_1)

    pixels = img.tile(t=4, y=20, x=30, dt=1, dy=5, dx=3)
    pixels_smooth = img.smoothed_tile(
        t=4, y=20, x=30, dt=1, dy=5, dx=3, sigma_z=0, sigma_yx=0
    )

    assert pixels.shape == pixels_smooth.shape
    assert (pixels_smooth == pixels).all()

    pixels_smooth = img.smoothed_tile(
        t=4, y=20, x=30, dt=1, dy=5, dx=3, sigma_z=0.75, sigma_yx=1.5
    )
    assert (pixels_smooth != pixels).any()

    pixels_smooth = img.smoothed_tile(
        t=4, y=20, x=30, dt=1, dy=5, dx=3, sigma_z=0.75, sigma_yx=3.578
    )
    assert (pixels_smooth != pixels).any()
