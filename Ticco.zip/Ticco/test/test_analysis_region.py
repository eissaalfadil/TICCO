from ticco import AnalysisRegions


def test_analysis_regions_pixels(path_mask_1):
    regions = AnalysisRegions(path_mask_1)

    assert regions._pixels().shape == (100, 200)


def test_analysis_regions_pos_yx(path_mask_1):
    regions = AnalysisRegions(path_mask_1)
    assert regions.shape_yx == (100, 200)
    assert regions.n_regions == 2

    coors = regions.pos_yx(0)
    for coor in coors:
        assert len(coors[0]) == 2
        assert coor[0] < 100  # y image size is 100
        assert coor[1] < 200  # x image size is 200

    coors = regions.pos_yx(1)
    for coor in coors:
        assert len(coors[0]) == 2
        assert coor[0] < 100  # y image size is 100
        assert coor[1] < 200  # x image size is 200


def test_analysis_regions_n_pixels(path_mask_1):
    regions = AnalysisRegions(path_mask_1)
    assert regions.n_pixels[0] == 2806
    assert regions.n_pixels[1] == 532
