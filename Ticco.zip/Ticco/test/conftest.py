import pytest
from pathlib import Path


@pytest.fixture
def path_test_data():
    return Path(__file__).parent / "test_data"

@pytest.fixture
def path_mask_1():
    return Path(__file__).parent / "test_data/img_1_mask.tif"


@pytest.fixture
def path_img_1():
    return Path(__file__).parent / "test_data/img_1.ome.tif"
