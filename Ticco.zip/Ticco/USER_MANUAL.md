# Ticco User Manual

This manual covers both ways to use Ticco:

1. Python command-line package (`ticco`)
2. Fiji plugin package (`Plugins > Ticco > Run Ticco`)

## 1. What Ticco Does

Ticco computes time-integrated cross-correlation between two channels in time-lapse microscopy data.

Inputs:
- image file (time series)
- binary mask image defining analysis regions

Outputs:
- correlation OME-TIFF image
- per-region CSV tables
- aggregated CSV table
- CSV with parameter settings

## 2. Installation: Python Package

### 2.1 Create environment

Example (mamba/conda):

```bash
mamba create -n venv-ticco python=3.11 -y
mamba activate venv-ticco
```

### 2.2 Install Ticco

From the Ticco project root:

```bash
cd "/Volumes/My_Book_Duo/Data/SUSHI/Ticco"
pip install .
```

### 2.3 Verify installation

```bash
ticco --help
```

If `ticco` is not found, use the full executable path, e.g.:

```bash
/Users/eissaa/mamba/envs/venv-ticco/bin/ticco --help
```

### 2.4 Dependency note (important)

For compatibility with `aicsimageio/tifffile`, use NumPy 1.x:

```bash
pip install "numpy<2" "zarr<2.16.0,>=2.6" entrypoints
```

## 3. Installation: Fiji Package

### 3.1 Install into Fiji

```bash
cd "/Volumes/My_Book_Duo/Data/SUSHI/Ticco/imagej"
./install_to_fiji.sh "/Applications/Fiji"
```

This installs plugin files into Fiji plugin/script folders.

### 3.2 Start Fiji

- Fully quit and reopen Fiji.
- If needed, run `Help > Refresh Menus`.
- Open `Plugins > Ticco > Run Ticco`.

## 4. Using Ticco from Fiji (ROI-first workflow)

When you run `Plugins > Ticco > Run Ticco`:

1. Select input image.
2. Image opens in Fiji.
3. Draw ROI(s) and click **Add** in ROI Manager for each region.
4. Click **OK** in the plugin prompt.
5. Plugin automatically creates mask and saves it next to the image as:
   - `<image_stem>_mask.tif`
6. Enter analysis parameters (`dyx`, `dt`, `sigma_yx`, `sigma_z`) and result folder.
7. Run analysis.

The plugin then calls the Python `ticco` executable.

### 4.1 Required field in Fiji dialog

Set `ticco executable` to the full path if needed:

`/Users/eissaa/mamba/envs/venv-ticco/bin/ticco`

## 5. Using Ticco from Command Line

Current CLI usage:

```bash
ticco path_to_image path_to_mask path_to_result_folder --dyx 4 --dt 2 --sigma_yx 1.0 --sigma_z 1.0
```

Example:

```bash
/Users/eissaa/mamba/envs/venv-ticco/bin/ticco \
"/path/to/image.tif" \
"/path/to/image_mask.tif" \
"/path/to/results" \
--dyx 4 --dt 2 --sigma_yx 1.0 --sigma_z 1.0
```

## 6. Output Files

For input image `my_image.tif`, outputs in result folder include:

- `my_image_corr.ome.tif`
- `my_image_result_region_0.csv` (and additional region files)
- `my_image_result_aggregated.csv`
- `my_image_corr_parameters.csv`

## 7. Performance Tips

Ticco is CPU-based (no GPU acceleration in current version).

To speed up runs:
- decrease `dyx`
- decrease `dt`
- set `sigma_yx=0` and `sigma_z=0` if smoothing is not needed
- reduce ROI area (mask fewer pixels)

## 8. Troubleshooting

### `ticco: command not found`

Set full executable path in Fiji:
`/Users/eissaa/mamba/envs/venv-ticco/bin/ticco`

### NumPy/tifffile error mentioning `newbyteorder`

Downgrade NumPy and align deps:

```bash
pip install "numpy<2" "zarr<2.16.0,>=2.6" entrypoints
```

### Plugin not visible in Fiji

1. Restart Fiji.
2. `Help > Refresh Menus`.
3. Ensure installation was run against the active Fiji directory.

## 9. Publishing to GitHub (recommended layout)

Include at least:

- `src/ticco/...` (Python package)
- `pyproject.toml`
- `README.md`
- `imagej/` (Fiji package + installer)
- `USER_MANUAL.md` (this file)

Then push to GitHub as your main project documentation and distribution source.
