# ticco
**Ti**me Integrated **C**ross **Co**rrelation

## Author

Christoph Möhl 2024

christoph@moehl-data-servides.de

https://moehl-data-services.de

## Method Description

With time integrated cross correlation, a pearson correlation coefficient between two image channels is calculated in a four-dimensional space (one time dimension, three space dimensions).

The correlation is calculated for each pixel by taking into account the pixel's local neighborhood (temporal and spacial neighborhood).
The neighborhood is defined by the parameters `dyx` and `dt`. The neighborhood always includes all pixels in z dimension. The image tile defining the pixel's neighborhood has a size of `2* dyx + 1` pixels in x and y, `2* dt + 1` frames in t and all pixels along z.

In the following scheme, the pixel neighborhood is shown for two dimensions, omitting the z and y dimension:
![scheme pixel neighborhood](scheme.png)

Before correlation is calculated, the image tile is smoothed with a three dimensional gaussian filter in x, y and z. The amount of smoothing is defined in x and y by `sigma_yx` and along z by `sigma_z`. To avoid edge effects, the tile is increased by 2* `sigma_yx` for smoothing. For the calculation of the correlation, the tile is reduced to its original size after smoothing.

### Why Gaussian Smoothing?
By applying a gaussian filter, we do not only filter out noise, we also reduce the resolution. Denoising is not necessary for correlation analysis, however downsizing the resolution could be beneficial to account for chromatic shift between the two channels.

### Handling Large Data
`ticco` is designed to work with very large datasets. When processing the datasets, tiles are loaded sequentially into memory. It should be possible to process images >10GB with a usual laptop.

### Tipps for Parameter Settings

* `sigma` parameter for smoothing should be significantly smaller than
  `d_yx`. Otherwise all pixel values within the template are rather identical and spatial correlation can not be measured.


### How to interpret results?

* If correlation is 1.0 for a certain pixel, the pixel neighborhood of the two channels have exact same structures (although could have different brightness), and the structures move in exact the same way.

* If correlation is -1.0 for a certain pixel, the pixel neighborhod of the two channels have exact inverse structures. A black structure in channel one corresponds exactly to a white structure in channel two. The structures move in the exact same way in both channels.

* If correlation is close to 0.0 for a certain pixel, there are no correlated structures and no correlated movement.


## How to Install

Ticco is supported for Linux, Mac OS and Windows and tested on Python version 3.10.

* Install Anaconda or Miniconda (Miniconda would be sufficient): https://docs.anaconda.com/free/anaconda/install/index.html

* Create a virtual environment for your `ticco` installation:

```sh
conda create -n venv-ticco python=3.10
```

* Install `ticco`

```sh
conda activate venv-ticco # activate the virtual environment
cd path/to/ticco # navigate to source files
pip install . # install with pip
```


## Usage

### Define Analysis Regions with `Fiji`
* Open the dataset you want to define regions for with `Plugins>>Bio-Formats-Importer` and check `Use virtual Stack` if dataset is too large for memory.

* Open `Analyze>>Tools>>ROI Manager`
* In the Fiji main panel, select the `Draw Polygons` icon and draw a polygon on your image. The Polygon defines the region you want to analyze.
* Add the ROI to the `ROI Manager`.
* If needed, draw more Polygons and add them to the `ROI Manager`.
* Select the first ROI in the `ROI Manager` and execute `Edit>>Selection>>Create Mask`. A new binary image with the first polygon will be created.
* Repeat this for all ROIs. In the end you should have one 2D Mask image with multiple white regions defining your analysis regions.
*Save the mask image as `ome.tif` by using `Plugins>>Bioformats Exporter`.



### Measure Time Integrated Cross Corellation with `ticco`
`ticco` is a command line tool. Open your terminal, activate the virtual environment where ticco is installed and execute `ticco` command with suitable parameters.
```sh
conda activate venv-ticco
```

#### Usage Examples


* Basic usage with default parameters
```sh
ticco path/to/image.czi  path/to/results
```
In this case, the mask file must be located in the same folder as the image and must have the default mask name `path/to/image_mask.tif`. The default mask name equals the image name with suffix `_mask` and file extension `.tif`.

* Usage with custom parameters
```sh
ticco path/to/image.czi  path/to/results --mask path/to/my_mask.tif --dyx 10 dt 5 --sigma_yx 0.8 --sigma_z 0.5
```
Here, we have an increased time window (2*dt+1 = 11 frames), an increased spatial window (21 pixels in x and y) and decreased gaussian smoothing. We also have a custom mask name.

* Batch mode to process multiple images at once

```sh
ticco path/to/images path/to/results  --filename-wildcard '*.czi' # process all czi files in folder

ticco path/to/images path/to/results  --filename-wildcard '*WT_Control*.czi' #process all czi files that contain 'WR_Control' in their name
```
In batch mode, the first argument is the folder, where all images and masks are located. Masks must have the default mask name. Custom mask names are not possible in batch mode. To activate batch mode, you just have to provide the `--filename-wildcard` argument to specify a certain filenmame pattern for batch processing. Images are processed in parallel.


#### Results

* An `ome.tif` image with pearson correlation values for all calculated pixels. This image might be displayed, e.g. in `Fiji` with some false color map.

* For each region, a csv table is produced, containing coordinates and pearson correlation values for each calculated pixel.

* A csv table with aggreagated values. The mean values for `x` and `y` define the region's centroid coordinates.

* A csv table with parameter settings.


#### Parameter Reference

Use `ticco -h` or `ticco --help` to list all possible parameters:

```sh
ticco -h

usage: ticco [-h] [--mask MASK] [--dyx DYX] [--dt DT] [--sigma_yx SIGMA_YX] [--sigma_z SIGMA_Z] [--filename-wildcard FILENAME_WILDCARD]
             path_to_image path_to_result_folder

Time integrated cross correlation of 5D image data. By Christoph Möhl 2024.

positional arguments:
  path_to_image         path to input image or path to folder with input images and masks.
  path_to_result_folder
                        path to result folder

options:
  -h, --help            show this help message and exit
  --mask MASK           path to mask image (must be 2D, same size in y and x as the input image). If not set, mask images must have the same name as the
                        input image with a '_mask.tif' suffix and must be located in the same folder as the input image: 'path/to/image.czi' ->
                        'path/to_image_mask.tif (default: None)
  --dyx DYX             correlation window size in y and x: 2 * dyx + 1 (default: 4)
  --dt DT               correlation window size in time: 2 * dt + 1 (default: 2)
  --sigma_yx SIGMA_YX   sigma for gaussian smoothing in y and x (use 0 for no smoothing) (default: 1.0)
  --sigma_z SIGMA_Z     sigma for gaussian smoothing in z (use 0 for no smoothing) (default: 1.0)
  --filename-wildcard FILENAME_WILDCARD
                        For processing in batch mode. E.g. '*.czi' to process all czi images in the folder defined in path_to_image. (default: None)
  --no-multiprocessing  Disbale multiprocessing (default: False)
## ImageJ/Fiji Plugin Package

An ImageJ/Fiji wrapper package is available in:

`imagej/`

It provides a Fiji command that runs `ticco` with a GUI dialog:

`Plugins > Ticco > Run Ticco`

See installation and packaging instructions in:

`imagej/README.md`
