from aicsimageio import AICSImage
from pathlib import Path
from scipy.ndimage import gaussian_filter
from math import ceil


class Image:
    def __init__(self, img_path: Path):
        self.image_path = img_path
        self.img = AICSImage(self.image_path)

        self.nframes = self.img.dims.T
        self.nchannels = self.img.dims.C
        self.shape_zyx = (self.img.dims.Z, self.img.dims.Y, self.img.dims.X)

    def pixel_sizes_zyx(self) -> tuple:
        return (
            self.img.physical_pixel_sizes.Z,
            self.img.physical_pixel_sizes.Y,
            self.img.physical_pixel_sizes.X,
        )

    def tile(self, t: int, y: int, x: int, dt: int, dy: int, dx: int):
        def _p_range(x, dx):
            return list(range(x - dx, x + dx + 1))

        # z_range = list(range(0, self.shape_zyx[0]))
        t_range = _p_range(t, dt)
        y_range = _p_range(y, dy)
        x_range = _p_range(x, dx)
        pixeldata = self.img.get_image_data(
            "CTZYX",
            # C=[0,1],
            # Z=z_range,
            T=t_range,
            Y=_p_range(y, dy),
            X=_p_range(x, dx),
        )

        assert pixeldata.shape[-1] > 0, f"out of range x axis: {x_range}"
        assert pixeldata.shape[-2] > 0, f"out of range y axis: {y_range}"
        assert pixeldata.shape[1] > 0, (
            f"selected time indices {t_range}"
            f" not valid for {self.nframes} time frames"
        )
        return pixeldata

    def smoothed_tile(
        self,
        t: int,
        y: int,
        x: int,
        dt: int,
        dy: int,
        dx: int,
        sigma_z: int,
        sigma_yx: int,
    ):
        ddyx = ceil(sigma_yx)
        dx_ext = dx + ddyx
        dy_ext = dy + ddyx

        p = self.tile(t=t, y=y, x=x, dt=dt, dy=dy, dx=dx)
        pixels = self.tile(t=t, y=y, x=x, dt=dt, dy=dy_ext, dx=dx_ext)

        smoothed = gaussian_filter(pixels, sigma=(0, 0, sigma_z, sigma_yx, sigma_yx))

        if ddyx > 0:
            return smoothed[:, :, :, ddyx:-ddyx, ddyx:-ddyx]
        return smoothed
