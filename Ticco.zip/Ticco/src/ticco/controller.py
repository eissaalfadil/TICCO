import numpy as np
import pandas as pd
import logging
from aicsimageio.writers import OmeTiffWriter
from ticco.image import Image
from ticco.analysis_regions import AnalysisRegions
import sys

logger = logging.getLogger(__name__)

logger.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
logger.addHandler(handler)


class Controller:
    def __init__(
        self,
        img: Image,
        regions: AnalysisRegions,
        dyx: int,
        dt: int,
        sigma_yx: float = 0,
        sigma_z: float = 0,
    ):
        assert dyx * 2 + 1 < img.shape_zyx[1]
        assert dyx * 2 + 1 < img.shape_zyx[2]
        assert dt * 2 + 1 < img.nframes

        self.img = img
        self.regions = regions

        shape_tyx = (img.nframes, img.shape_zyx[1], img.shape_zyx[2])
        self.result_img = np.zeros(shape_tyx)
        self.result_tbls = [pd.DataFrame(), pd.DataFrame()]

        self.dyx = dyx
        self.dt = dt

        self.sigma_yx = sigma_yx
        self.sigma_z = sigma_z

    def parameters(self):
        p = {
            "filename": self.img.image_path,
            "window_size_yx": self.dyx * 2 + 1,
            "window_size_z": self.img.shape_zyx[0],
            "window_size_t": self.dt * 2 + 1,
            "sigma_yx": self.sigma_yx,
            "sigma_z": self.sigma_z,
        }
        return p

    def to_ome_tif(self, savename):
        logger.info(f"Exporting correlation image to {savename}")
        OmeTiffWriter.save(self.result_img, savename, dim_order="ZYX")

    def export_data(self, savefolder):
        logger.info(f"Exporting result data to {savefolder}")
        img_name_stem = self.img.image_path.name.split(".")[0]
        aggs = []
        for e, df in enumerate(self.result_tbls):
            savename = f"{img_name_stem}_result_region_{e}.csv"
            df.to_csv(savefolder / savename, index=False)

            agg = df.describe()[["region_id", "pearson_correlation", "y", "x"]]
            agg["region_id"] = e
            aggs.append(agg)

        aggs = pd.concat(aggs, axis=0)
        savename = f"{img_name_stem}_result_aggregated.csv"
        aggs.to_csv(savefolder / savename, index=True)

        parameters = pd.Series(self.parameters())
        savename = f"{img_name_stem}_corr_parameters.csv"
        parameters.to_csv(savefolder / savename)

    def corr_tile(self, t: int, y: int, x: int):
        try:
            if self.sigma_yx == 0 and self.sigma_z == 0:
                pixels = self.img.tile(
                    t=t, y=y, x=x, dt=self.dt, dy=self.dyx, dx=self.dyx
                )
            else:
                pixels = self.img.smoothed_tile(
                    t=t,
                    y=y,
                    x=x,
                    dt=self.dt,
                    dy=self.dyx,
                    dx=self.dyx,
                    sigma_z=self.sigma_z,
                    sigma_yx=self.sigma_yx,
                )
        except AssertionError:
            logger.debug(
                f"position P(x={x}, y={y}) too close to edge. Correlation is set to nan."
            )
            return np.nan

        c1 = pixels[0, :, :, :, :]
        c2 = pixels[1, :, :, :, :]

        pearson_corr = np.corrcoef(c1.flatten(), c2.flatten())[1, 0]

        return pearson_corr

    def corr_region(self, region_id: int):
        pos_yx = self.regions.pos_yx(region_id)

        t_min = self.dt
        t_max = self.img.nframes - self.dt - 1

        res = {"region_id": [], "t": [], "y": [], "x": [], "pearson_correlation": []}
        n_nan = 0
        n_all = 0

        n_frames = t_max - t_min
        n_pixels = self.regions.n_pixels[region_id] * n_frames
        counter = 0

        for t in range(t_min, t_max):
            for p in pos_yx:
                y = p[0]
                x = p[1]
                pearson_corr = self.corr_tile(t=t, y=y, x=x)
                self.result_img[t, y, x] = pearson_corr

                res["region_id"].append(region_id)
                res["t"].append(t)
                res["y"].append(y)
                res["x"].append(x)
                res["pearson_correlation"].append(pearson_corr)

                if np.isnan(pearson_corr):
                    n_nan += 1
                n_all += 1

                counter += 1
                progress = round(100.0 * counter / n_pixels, 2)
                if counter % 5000 == 0:
                    logger.info(
                        f"{self.img.image_path.stem}: {progress}% calculated of region {region_id}"
                    )

        if n_nan > 0:
            nan_percent = round(n_nan / float(n_all) * 100, 2)
            logger.warning(
                f"Correlation could not be calculated for "
                f"{nan_percent}% ({n_nan}) pixels in region "
                f"{region_id}. {n_nan } Pixels were too close to image edge."
            )
        res = pd.DataFrame(res)
        self.result_tbls[region_id] = res
        return res
