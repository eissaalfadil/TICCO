import argparse
import logging
import sys
from pathlib import Path
from ticco import AnalysisRegions, Controller, Image
from multiprocessing import Process

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
logger.addHandler(handler)


def _process(
        path_to_image, path_to_mask, dyx, dt, sigma_yx, sigma_z, path_to_result_folder
    ):
        assert path_to_image.exists(), f"image not found: {path_to_image}"
        assert path_to_mask.exists(), f"mask not found: {path_to_mask}"

        regions = AnalysisRegions(path_to_mask)
        img = Image(path_to_image)
        c = Controller(
            img,
            regions,
            dyx=dyx,
            dt=dt,
            sigma_yx=sigma_yx,
            sigma_z=sigma_z,
        )

        for i in range(c.regions.n_regions):
            c.corr_region(i)
            logger.info(
                f"{path_to_image.stem}: Region {i} (of {c.regions.n_regions}) finished"
            )

        c.export_data(path_to_result_folder)

        img_name_stem = c.img.image_path.name.split(".")[0]
        save_img_path = path_to_result_folder / f"{img_name_stem}_corr.ome.tif"
        c.to_ome_tif(save_img_path)


def main():
    parser = argparse.ArgumentParser(
        prog="ticco",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="Time integrated cross correlation of 5D image data. By Christoph Möhl 2024.",
    )

    parser.add_argument(
        "path_to_image",
        type=Path,
        help="path to input image or path to folder with input images and masks.",
    )

    parser.add_argument(
        "path_to_result_folder", type=Path, help="path to result folder"
    )

    parser.add_argument(
        "--mask",
        type=Path,
        default=None,
        help=(
            "path to mask image (must be 2D, same size in y and x as the input image). "
            "If not set, mask images must have the same name as the input image "
            "with a '_mask.tif' suffix and "
            "must be located in the same folder as the input image: "
            "'path/to/image.czi' -> 'path/to_image_mask.tif"
        ),
    )
    parser.add_argument(
        "--dyx",
        type=int,
        default=4,
        help="correlation window size in y and x: 2 * dyx + 1",
    )
    parser.add_argument(
        "--dt", type=int, default=2, help="correlation window size in time: 2 * dt + 1"
    )
    parser.add_argument(
        "--sigma_yx",
        type=float,
        default=1.0,
        help="sigma for gaussian smoothing in y and x (use 0 for no smoothing)",
    )
    parser.add_argument(
        "--sigma_z",
        type=float,
        default=1.0,
        help="sigma for gaussian smoothing in z (use 0 for no smoothing)",
    )
    parser.add_argument(
        "--filename-wildcard",
        type=str,
        default=None,
        help=(
            "For processing in batch mode. E.g. '*.czi' to process all "
            "czi images in the folder defined in path_to_image."
        ),
    )
    parser.add_argument(
        "--no-multiprocessing",
        action="store_true",
        help=("Disbale multiprocessing"),
    )

    args = parser.parse_args()

    def _default_mask_path(path_to_image):
        default_mask_filename = f"{path_to_image.stem}_mask.tif".replace(".ome", "")
        return path_to_image.parent / default_mask_filename

    if args.filename_wildcard is not None:
        assert (
            args.path_to_image.is_dir()
        ), "in batch mode, path_to_image must be a directory"
        paths_to_image = list(args.path_to_image.glob(args.filename_wildcard))
        assert (
            len(paths_to_image) > 0
        ), f"no images found for {args.filename_wildcard} in {args.path_to_image}"
        assert args.mask is None, "masks must have default naming in batch mode"

    else:
        # no batch mode
        paths_to_image = [args.path_to_image]

    if args.mask is None:
        paths_to_mask = [_default_mask_path(img_path) for img_path in paths_to_image]
    else:
        paths_to_mask = [args.mask]
        assert len(paths_to_image) == 1

    assert (
        args.path_to_result_folder.is_dir()
    ), f"not a directory: {args.path_to_result_folder}"



    procs = []
    if args.no_multiprocessing:
        multiprocessing = False
    else:
        multiprocessing = True

    for path_to_image, path_to_mask in zip(paths_to_image, paths_to_mask):
        if multiprocessing:
            proc = Process(
                target=_process,
                args=(
                    path_to_image,
                    path_to_mask,
                    args.dyx,
                    args.dt,
                    args.sigma_yx,
                    args.sigma_z,
                    args.path_to_result_folder,
                ),
            )
            procs.append(proc)
            proc.start()
        else:
            _process(
                path_to_image,
                path_to_mask,
                args.dyx,
                args.dt,
                args.sigma_yx,
                args.sigma_z,
                args.path_to_result_folder,
            )

    if multiprocessing:
        for proc in procs:
            proc.join()
