from pathlib import Path
from aicsimageio import AICSImage
from scipy.ndimage import label
import numpy as np


class AnalysisRegions:
    def __init__(self, mask_path: Path):
        self.mask_path = mask_path

        self.img = AICSImage(self.mask_path)

        self.shape_yx = (self.img.dims.Y, self.img.dims.X)
        self._calc_labels()

    def _pixels(self):
        px = self.img.get_image_data("YX")
        px[px > 0] = 1
        return px.astype(np.int8)

    def pos_yx(self, region_id):
        assert region_id < self.n_regions

        ymax = self.shape_yx[0]
        xmax = self.shape_yx[1]
        ygrid, xgrid = np.mgrid[:ymax, :xmax]

        ypos = ygrid[self.labels == region_id + 1]
        xpos = xgrid[self.labels == region_id + 1]

        return np.stack((ypos, xpos)).transpose()

    def _calc_labels(self):
        structure = np.ones((3, 3), dtype=np.int8)
        self.labels, self.n_regions = label(self._pixels(), structure)

        labels_flat = self.labels.flatten()
        n_pixels = []
        for i in range(self.n_regions):
            n_pixels.append((labels_flat == i + 1).sum())
        self.n_pixels = n_pixels
