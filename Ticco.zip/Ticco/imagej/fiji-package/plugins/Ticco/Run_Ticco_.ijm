macro "Run Ticco" {
    pathToImage = File.openDialog("Select input image");
    if (pathToImage=="") exit("Canceled.");

    open(pathToImage);
    imageTitle = getTitle();
    imageWidth = getWidth();
    imageHeight = getHeight();

    run("ROI Manager...");
    roiManager("reset");

    waitForUser(
        "Draw ROIs on the opened image",
        "Use any ROI tool and click Add in ROI Manager for each region.\n"
      + "When done, click OK to create and save the mask, then start analysis."
    );

    roiCount = roiManager("count");
    if (roiCount==0) {
        exit("No ROI in ROI Manager. Add at least one ROI and run again.");
    }

    imageDir = File.getDirectory(pathToImage);
    imageName = File.getName(pathToImage);
    dotPos = lastIndexOf(imageName, ".");
    if (dotPos>0)
        imageStem = substring(imageName, 0, dotPos);
    else
        imageStem = imageName;

    // Match ticco default naming for .ome.tif inputs.
    if (endsWith(imageStem, ".ome"))
        imageStem = substring(imageStem, 0, lengthOf(imageStem)-4);

    maskPath = imageDir + imageStem + "_mask.tif";

    newImage("Ticco_Mask", "8-bit black", imageWidth, imageHeight, 1);
    setForegroundColor(255, 255, 255);
    for (i=0; i<roiCount; i++) {
        roiManager("Select", i);
        run("Fill");
    }
    saveAs("Tiff", maskPath);
    close(); // close mask image

    Dialog.create("Run Ticco Parameters");
    Dialog.addMessage("Mask saved to:\n" + maskPath);
    Dialog.addString("Result folder", imageDir);
    Dialog.addNumber("dyx", 4);
    Dialog.addNumber("dt", 2);
    Dialog.addNumber("sigma_yx", 1.0);
    Dialog.addNumber("sigma_z", 1.0);
    Dialog.addString("ticco executable", "/Users/eissaa/mamba/envs/venv-ticco/bin/ticco");
    Dialog.addCheckbox("Open result folder when done", true);
    Dialog.show();

    resultFolder = Dialog.getString();
    dyx = Dialog.getNumber();
    dt = Dialog.getNumber();
    sigmaYx = Dialog.getNumber();
    sigmaZ = Dialog.getNumber();
    ticcoExecutable = Dialog.getString();
    openResultFolder = Dialog.getCheckbox();

    if (lengthOf(resultFolder)==0)
        exit("Result folder is required.");

    cmd = "\"" + ticcoExecutable + "\" \"" + pathToImage + "\" \"" + maskPath + "\" \"" + resultFolder + "\"";
    cmd = cmd + " --dyx " + d2s(dyx, 0);
    cmd = cmd + " --dt " + d2s(dt, 0);
    cmd = cmd + " --sigma_yx " + d2s(sigmaYx, 3);
    cmd = cmd + " --sigma_z " + d2s(sigmaZ, 3);

    print("\\Clear");
    print("Running: " + cmd);
    out = exec("/bin/bash", "-lc", cmd + " 2>&1");
    print(out);

    selectWindow(imageTitle);

    if (openResultFolder)
        exec("open", resultFolder);
}
