#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PACKAGE_ROOT="$ROOT_DIR/fiji-package"
DIST_DIR="$ROOT_DIR/dist"
OUTPUT_ZIP="$DIST_DIR/ticco-imagej-package.zip"

mkdir -p "$DIST_DIR"
rm -f "$OUTPUT_ZIP"

cd "$PACKAGE_ROOT"
zip -r "$OUTPUT_ZIP" scripts >/dev/null

echo "Created package: $OUTPUT_ZIP"
