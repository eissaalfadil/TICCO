#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/Fiji.app OR /path/to/Fiji"
  exit 1
fi

INPUT_PATH="$1"
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPTS_SRC_DIR="$ROOT_DIR/fiji-package/scripts"
PLUGINS_SRC_DIR="$ROOT_DIR/fiji-package/plugins"

if [[ ! -d "$INPUT_PATH" ]]; then
  echo "Path does not exist: $INPUT_PATH"
  exit 1
fi

declare -a TARGETS=()

# If a top-level Fiji folder is provided, install there.
if [[ -d "$INPUT_PATH/plugins" || -d "$INPUT_PATH/scripts" || -f "$INPUT_PATH/fiji" ]]; then
  TARGETS+=("$INPUT_PATH")
fi

# If a Fiji.app bundle is provided directly, install there.
if [[ "$INPUT_PATH" == *.app ]]; then
  TARGETS+=("$INPUT_PATH")
fi

# If a top-level Fiji folder containing Fiji.app is provided, install in Fiji.app too.
if [[ -d "$INPUT_PATH/Fiji.app" ]]; then
  TARGETS+=("$INPUT_PATH/Fiji.app")
fi

if [[ ${#TARGETS[@]} -eq 0 ]]; then
  echo "Could not detect a Fiji installation at: $INPUT_PATH"
  exit 1
fi

for FIJI_DIR in "${TARGETS[@]}"; do
  SCRIPTS_DST_DIR="$FIJI_DIR/scripts"
  PLUGINS_DST_DIR="$FIJI_DIR/plugins"

  mkdir -p "$SCRIPTS_DST_DIR"
  mkdir -p "$PLUGINS_DST_DIR"
  cp -R "$SCRIPTS_SRC_DIR"/* "$SCRIPTS_DST_DIR"/
  cp -R "$PLUGINS_SRC_DIR"/* "$PLUGINS_DST_DIR"/

  echo "Installed script command: $SCRIPTS_DST_DIR/Plugins/Ticco/Run_Ticco.jy"
  echo "Installed macro plugin: $PLUGINS_DST_DIR/Ticco/Run_Ticco_.ijm"
done

echo "In Fiji, run it from: Plugins > Ticco > Run Ticco"
