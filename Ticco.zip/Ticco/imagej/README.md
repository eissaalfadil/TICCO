# Ticco ImageJ/Fiji Package

This folder adds a Fiji plugin wrapper around the existing `ticco` Python CLI.

## What is included

- `fiji-package/scripts/Plugins/Ticco/Run_Ticco.jy`
  - Fiji command script with a GUI dialog for all key `ticco` parameters.
- `install_to_fiji.sh`
  - Copies the script into an existing Fiji installation.
- `build_imagej_package.sh`
  - Creates `dist/ticco-imagej-package.zip` for distribution.

## Prerequisites

1. Fiji installed.
2. A Python environment where `ticco` is installed and runnable from terminal:
   - `pip install .` from the Ticco root.
3. The `ticco` executable available on `PATH`, or provide the full path in the Fiji dialog field `ticco executable`.

## Installation

From this `imagej` folder:

```bash
./install_to_fiji.sh /path/to/Fiji.app
```

Restart Fiji.

## Usage in Fiji

Run:

`Plugins > Ticco > Run Ticco`

Set:

- input image path (or folder for batch mode)
- result folder
- optional mask image
- `dyx`, `dt`, `sigma_yx`, `sigma_z`
- optional filename wildcard for batch mode
- optional `ticco executable` path

The script logs command output to the Fiji Log window.

## Package for sharing

```bash
./build_imagej_package.sh
```

Then distribute:

`dist/ticco-imagej-package.zip`

Users can unzip and copy the `scripts` folder into `Fiji.app/scripts`.
